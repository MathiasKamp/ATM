create procedure dbo.sp_GetAccount

    @name              varchar(50)   = NULL,
    @lastName              varchar(50)   = NULL
   
    
AS
BEGIN
    set nocount on
    
    select * from Account where name = @name and lastName = @lastName;
   
    end
go

